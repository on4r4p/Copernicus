##Copernicus
 

Osint tool to get results from
youtube,google,bing,yahoo,britishtelecom,pagesblanches,paginasblancas,
spravkaru,dastelefonbush,yellowpages,instagram,twitter,youtube,wechat,googleplus,
linkedin,myspace,flickr,foursquare,photobucket,picturetrail,wayn,dekd,
pinterest,badoo,torchtorsearch,blogger,tumblr,skype,facebook,tineye,irclogs,darksearch,
break,colourlover,raptr,bodyspace,freesound,mylot,mixcloud,porn,goodreads,singlemuslim,
playlist,thegardian,steam,ustream,geekgrade,picturetrail,myfitnesspal,myspace,lastfm,
ifttt,rateyourmusic,cheezburger,dekd,rapid7,angellist,okcupid,bugcrowd,meetzur,foursquare,delicious,
peekyoulivejasmine,interpals,mixlr,codeplex,storycorp,ivejournal,eporner,ahmia,audioboom,ask,
wishlist,foodspotting,sporcle,xboxtag,mate1,vimeo,slideshare,pornhub,funnyordie,wanelo,hubpages,
onion.linkdeviantart,pinterest,dailymotion,wayn,fanpop,soup,pinkbike,photoblog,blip,smiteguru,
yippy,internetarchive,snooth,smule,newsvine,stupidcancer,twitter,tripit,cruisemate,wikipedia,
pastebin,flickr,blogspot,librarything,scratch,iampregnant,projectares,knowem,youtube,xvideo,
linkedin,buzzfeed,badoo,myspace,producthunt,adultfirendfinder,etsy,darksearch,technet.microsoft,
cafemom,soundcloud,vidme,anobii,vine,tumblr,setlist,slashdot,psn,pof,vk,weedlife,friendfindx,
blackplanet,wechat,marketingland,diigo,trip,about.me,xhamster,googleplus,fotolog,untappd,
medium,diy,klout,imageshack,voat,plurk,cardomain,seoclerks,xanga,github,vampirefreaks,
instagram,klear,wordpress,wattpad,mybuilder,twitch,netvibe,authorstream,rottentomatoes,
reddit,cashme,kongregate,onionsearchengine,atlassian,redtube,imgur,viddler,lanyrd,periscope,
shopcade,gravatar,tf2items,massroot,eightbitme,fiverr,moddb,matchdoctor,photobucket,
videolike,muckrack,smugmug,speakerdeck,voices,tripadisor,flipboard,bitbucket,instructables,
blogmarks,yelp,ello,abou.to,stream.me,getsatisfaction,crokes,codementor,500px,houzz,
contently,scribd,venmo,canva,creativemarket,bandcamp,wikia,reverbnation,mig.me,
designspiration,eyeem,miiverse,kano,smashcast,newgrounds,younow,postagon,
 blogdrive,blogger,blogher,blogigo,blogster,blogtalkradio,bloopist,bold,disqus,dreamwidth,
hatena,insanejournal,intensedebate,issuu,jigsy,livejournal,medium,moonfruit,myblogu,notey,
pen,postagon,roojoom,sailblogs,soup,thoughts,tumblr,typepad,wallinside,weebly,wordpress,
bitLy,blogmarks,cloudytags,delicious,designfloat,diigo,folkd,43marks,gimmebar,librarything,
myhq,mysitevote,netvouz,papaly,pinterest,posteet,segnalo,stumbleupon,symbaloo,trendhunter,
wanelo,weheartit,wishlistr,wookmark,xerpi,xmarks,activerain,adsoftheworld,angel,apsense,
authorstream,biggerpockets,bizsugar,coroflot,ebay,edocr,etsy,fool,getsatisfaction,kiva,
linkedin,profnetconnect,referralkey,ryze,siftery,slack,slideserve,smarterer,snappages,cash,
stocktwits,storeboard,testq,thisnext,tradingview,trepup,uservoice,venmo,wamda,weblo,
xmind,yatedo,3tags,academia,blackplanet,blurb,blurtopia,bookcrossing,boonex,cafemom,
dirtyus,duno,empireavenue,eventful,faceparty,faces,fixya,fluther,fmylife,freelywheely,
friendsite,goodreads,grassfire,groups,hi5,hubpages,hubski,instructables,kickstarter,
kiwibox,knowem,lafango,lefora,lifeknot,madwhips,measuredup,migente,minds,myspace,
nexopia,ning,pinkbike,postcrossing,proboards,qmpeople,realitysandwich,seenlife,
sitepoint,skyrock,slidepoint,slideshare,sodahead,spruz,sqeeqee,steampowered,stylebistro,
tagged,tigweb,todaysmeet,toluna,unitedcats,untappd,vk,voat,wireclub,wittyprofiles,xanga,
yuku,artfire,behance,burdastyle,canva,chairish,chictopia,choozle,colourlovers,creativemarket,
crokes,designspiration,deviantart,dwell,fancy,hometalk,jimdo,mindmeister,myfolio,
opendesktop,qbn,society6,wittygraphy,9gag,arcadetrail,becomegorgeous,boxedup,cardomain,
chess,coolspotters,cracked,crunchyroll,destructoid,ebaumsworld,fanpop,fashionfreax,
gaiaonline,gamespot,grindtv,icanhascheezburger,ichive,knowyourmeme,koinup,kongregate,
letterboxd,librarious,linkibl,listal,metacritic,moddb,motortopia,n4g,newgrounds,oobgolf,patreon,
playerme,pwned,ranker,raptr,redbubble,shockwave,singsnap,snapzu,sportspyder,stage32,storify,
storybird,stylehive,tickld,trakt,voiceoftv,votable,wattpad,whiskeyconnosr,yardbarker,armchairgm,
athlinks,bakespace,culinate,dailymile,empowher,families,fatsecret,fitday,healthbubble,keeprecipes,
leafly,livestrong,menuism,mycyclinglog,myfitnesspal,nibbledish,seriouseats,snooth,sparkpeople,
steepster,strava,withfit,aboutme,abouto,allmyfaves,answers,appearoo,arrisweb,askfm,bloglovin,
calendly,citeulike,dojoess,duolingo,edmodo,flavorsme,flightaware,flipboard,freebase,gravatar,
growthhackers,huffduffer,ifttt,itsmyurls,khanacademy,listgeeks,listography,mouthshut,netvibes,
nouncy,pressfolios,qhub,quora,rrrather,scribd,shortfiction,Storeboard,studypool,tacked,thatisme,
trello,visualcv,webs,wikia,wikihow,wikipedia,workface,zotero,alternion,audioboo,ello,foodspotting,
foursquare,kiwi,littlelogs,mastodon,onsugar,plinky,plurk,posteezy,qooh,twitter,wadja,yoolink,
zedge,8tracks,allihoopa,audioboom,bandcamp,bandmix,bandsintown,blipfm,castroller,
concertwindow,datpiff,genius,hypem,jambase,lastfm,mixcloud,pitchmystuff,propellerheads,
purevolume,reverbnation,seatwish,songkick,spreaker,stereogum,thesixtyone,ultimateguitar,
youlicense,buzzfeed,ezyspot,fark,gawker,muckrack,myalltop,newsmeback,newsmix,newsvine,
openzine,popsugar,pusha,reddit,sportlobster,sportsrants,theartifice,thiscm,topix,upvoat,valme,
whuut,wikidot,wirefan,wunderground,23hq,500px,blipfoto,clipartme,dreamstime,expono,flickr,
fotki,fotobabble,fotochatter,fotolog,fotothing,freepik,gfycat,giphy,imageshack,imgfave,imgur,
instagram,jalbum,mobypicture,morguefile,photobucket,photodune,photopeach,piccsy,picturepush,
picturesocial,picturetrail,pixabay,postimg,purephoto,purestorm,photoshow,shutterstock,smugmug,
snaphotmobi,tabulas,thefancy,topy,twitxr,zenfolio,alternativeto,betanews,bitbucket,cnet,codecademy,
codementor,coderwall,creativelive,curious,customize,cybrhome,datacamp,dataworld,degreed,dribbble,
duxter,element14,f6s,github,hackaday,hackerrank,hackster,ipernity,keybase,mytechlogy,pastebin,
playfire,republic,scrim,silk,sketchfab,skillshare,slashdot,snipplr,sourceforge,startupwings,techdirt,
techsupportalert,toolbox,tracky,teamtreehouse,bewelcome,buffalo,exploroo,fodors,gapyear,gogobot,
lonelyplanet,lovento,roadtrippers,touristlink,travbuddy,travelblog,travellerspoint,travelpod,tripadvisor,
bambuser,break,clipmoon,coub,dailymotion,expotv,funnyordie,godtube,houzz,kaotic,liveleak,
metacafe,ovguide,periscope,photosynth,stream,tout,twitch,veoh,videobash,videojug,videosift,
vidme,vimeo,wonderhowto,(and more to come) about peoples.

1. No Smeging Api key required.

2. Will not get your ip banned.

3. Get images from Google,Bing,Yahoo

4. Filter each websites results to be sure to retreive what we looking for . (including pdf)

5. If strict search result failed for one website try another finding method helped by a list of words provided by user.

6. Catch all emails found in webpages .

7. Search in a french's city specified by user for family name ,adresses,phone numbers.
Search  all regions in France for family name ,adresses,phone numbers.
 Search  all cities in France with more than 10 thousand inhabitants for family name ,adresses,phone numbers (never tested  yet suspected to block your ip)
 
8. Search in United-Kingdom a city specified by user for family name ,adresses,phone numbers.
 Search  all cities in United-Kingdom for family name ,adresses,phone numbers.
 
9. Search in a spanish's city specified by user for family name ,adresses,phone numbers.
 Search all cities in Spain for family name ,adresses,phone numbers.
 
10. Search in a russian city's specified by user for family name ,adresses,phone numbers.
 Search all cities in Russia for family name ,adresses,phone numbers.
 
11. Search in an american's city specified by user for family name ,adresses,phone numbers.
 Search all States of Usa for family name ,adresses,phone numbers. 
 
12. Search german's city specified by user for family name ,adresses,phone numbers.
 Search all cities in Germany for family name ,adresses,phone numbers. 
 
13. Search social network relations with or without email provided or found or guessed. (509 websites)

14. (Search emailbiz.info if lastname provided or alias then ) Generate all possible combinations of mails adresses from first and last name or alias then check if they exist . If they exist , search for social network relations .
 
15. Search in Skype Directory (can use results to guess emails)
 
16. Search in Facebook Directory  (can use results to guess emails)

17. Search in Deepweb and Onion search engine 
Results from darksearch.com ,peekyou.com, onion.link , yippy.com ,ahmia.fi ,onionsearchengine.com , torchtorsearch.com

18. Search in Irc logs from various servers .
        (https://botbot.me/ http://tunes.org/ http://irc.slitaz.org/ http://logs.glob.uno/ https://krijnhoetmer.nl/irc-logs/ https://indieweb.org/irc/ http://eavesdrop.openstack.org/irclogs/ http://irclog.whitequark.org/ http://chat.alfresco.com/ http://ircbrowse.net http://www.wcnews.com/logs/ http://logs.nslu2-linux.org/livelogs http://irclogs.shortcircuit.net.au/ http://irclogs.ceph.widodh.nl/ https://fluidtypo3.org/community/ https://www.tryton.org/~irclog/ http://rbach.priv.at/Microformats/IRC/ https://log.bezut.info/ http://sbnc.khobbits.co.uk/log/logs/ https://irclogs.baserock.org/ http://carrier.6irc.net/metachan/ https://irclogs.ubuntu.com/ https://www.spi-inc.org/meetings/logs/ https://www.olimex.com/irc? https://irc.cakephp.org/ http://freecadlog.archivist.info/ https://irclogs.jackgrigg.com/ http://irc.koha-community.org/koha/ http://www.merproject.org/logs/ http://www.alwaysinnovating.com/irclog/ https://ghostscript.com/irclogs/ https://badcheese.com/~steve/atlogs/ http://c4evaspeaks.com https://irclog.perlgeek.de/ http://old.geotools.org http://riesvantwisk.com/home/irc-logs/ http://blockstack.slackarchive.io/ http://chat-logs.dcpython.org/ https://irclogs.deepin.io/deepin http://logs.collectionspace.org/ http://irc.minetest.ru/ https://irc.dokuwiki.org/ https://silverstripe.logged.nz/ http://tech.lds.org/irc/ http://globalqss.com/idempiere/irclog/ http://dig.csail.mit.edu/irc/dig/ http://www.webplatform.org/talk/chatlogs/ http://ilbot2.kohaaloha.com/koha/)
 
19. Compare avatars from Facebook ,Skype and the 10 first pictures from Google,Bing and Yahoo with Tineye , Google, Yandex Reverse Image database .
 
20. Then make a graph in neo4j or csv file.

^(Consider downloading [Linkification](https://addons.mozilla.org/fr/firefox/addon/linkification/)  for Firefox or [Clickable links](https://chrome.google.com/webstore/detail/clickable-links/mgamelhnfokapndfdodnmfiningckjia) for Chrome if you want to work directly in neo4j .)^

![ ](https://img4.hostingpics.net/pics/679611Capturedcrande20170628043121.png  "Title")

![No arg](https://img11.hostingpics.net/pics/998757menus.png  "No arg")

![Darsearch1](https://img11.hostingpics.net/pics/974710darksearch1.png  "Darsearch1")

![Darsearch2](https://img11.hostingpics.net/pics/176049darksearch2.png  "Darsearch2")

![Peekyou1](https://img11.hostingpics.net/pics/170524PIckyou1.png  "Peekyou1")

![Peekyou2](https://img11.hostingpics.net/pics/233575PIckyou2.png  "Peekyou2")

![Yippy1](https://img11.hostingpics.net/pics/331844Yippy1.png  "Yippy1")

![Yippy2](https://img11.hostingpics.net/pics/205515Yippy2.png  "Yippy2")

![OnionSearchEngine1](https://img11.hostingpics.net/pics/181504OnionsearchEngine1.png  "OnionSearchEngine1")

![OnionSearchEngine2](https://img11.hostingpics.net/pics/312980OnionsearchEngine2.png  "OnionSearchEngine2")

![Torch1](https://img11.hostingpics.net/pics/855493Torsearch1.png  "Torch1")

![Torch2](https://img11.hostingpics.net/pics/127820Torsearch2.png  "Torch2")

![Skype1](https://img11.hostingpics.net/pics/613852skype.png  "Skype1")

![Skype2](https://img11.hostingpics.net/pics/636052skype2.png  "Skype2")

![Facebook1](https://img11.hostingpics.net/pics/403844Facebook.png  "Facebook1")

![Emailbiz1](https://img11.hostingpics.net/pics/729208Emailbiz1.png  "Emailbiz1")

![Emailbiz2](https://img11.hostingpics.net/pics/490094Emailbiz2.png  "Emailbiz2")

![Testmail](https://img11.hostingpics.net/pics/809941testmail.png  "Testmail")

![Social1](https://img11.hostingpics.net/pics/740608Knowem.png  "Social1")

![Social2](https://img11.hostingpics.net/pics/470363Knowem2.png  "Social2")

![Social3](https://img11.hostingpics.net/pics/724035social2.png  "Social3")

![ ](http://img11.hostingpics.net/pics/139823resc.png  "search engine")


![ ](https://s24.postimg.org/3y8y56wcl/piximg.jpg  "gimg")

![IrcSearch](https://img11.hostingpics.net/pics/707973ircsearch.png  "IrcSearch")

![Image Reverse](https://img11.hostingpics.net/pics/902736Sbi.png  "Image Reverse")

![ ](http://img11.hostingpics.net/pics/384186Captcha.png  "yellowpages captcha bypass")


![Maltego graph](http://img15.hostingpics.net/pics/994737malti.png  "maltego")


![](http://img15.hostingpics.net/pics/938427copernicus0.png) 

		- usage: copernicus.py [-h] [-e Engine] [-l LANG] [-c2e]
		                     [-c2w ] [-f2e] [-n2w] [-sm ] [-sk LOGIN-PASSWORD] 
		                     [-sf LOGIN-PASSWORD] [-sa 'ALIAS'] [-s 'NAME'] 
		                     [-o output] [-f FAMILY NAME] [-a OPTION] [-tocsv FILENAME] [-c CITY] 
		                     [-i ] [io] [-m EMAIL] [-gm OPTION] [-fa TRUE-FALSE] 
		                     [-LS] [-t TIME]
		- optional arguments:
		
		       -h, --help            show this help message and exit
		       
		       -e Engine, Engine Use specific search engine: 
		       -e google,yahoo,bing,social,pagesblanches,social,britishtelecom,paginasblancas,
		       spravkaru,yellowpages,telefonbuch,skype,facebook,deepdarkweb,irc,tineye
		       
		       -l LANG, Country : en,zh-CN,es,ar,pt,ja,ru,fr,de...
		       
		       -tocsv Append result to existing file
		       
		       -c2e  Only use the city arg with search engine
		       
		       -c2w Only use the city arg with whitepages
		       
		       -f2e Search with full name not only Family name with skype or facebook 
		       -n2w Dont only use Family name with whitepages use fullname instead
		       
		       -sm , --scrapmail get all emails from results
		       
		       -sk LOGIN-PASSWORD,  Search Family name in Skype Directory.
		       
		       -sf LOGIN-PASSWORD,  Search Family name in Facebook Directory.

		       -sa 'ALIAS', Alias to Search
		       
		       -s 'NAME', Name to Search
		       
		       -o --output output to Neo4j or Csv.
		       
		       -f FAMILY NAME, --family FAMILY NAME
		       
		       -a OPTION, Word1,Word2,Word3
		       
		       -c CITY, --city   Specify city
		       
		       -i , Search and download pictures too
		       
		       -io , --imgonly Collect images and skip Google Bing and Yahoo search engine
		       
		       -m EMAIL,  will search for social network relation  about it
		       
		        
		       -t TIME, --timesleep Resting time before each requests ( random between 42 to x where x is your choice)
		        
		       -gm OPTION Find all emails permutation and check if they exist.
		       	 Options:
				 leet for l33tsp34k
				  .-_ are chosen separators
				 23,42 People often add birthdate/postalcode/fav number at the end  try to add some
				 badidea0000 to test all combinations from 0 to 9999 (even 2 digits is a bad idea). 
				 Another bad idea is the 'all' option which try over 4500 emails providers.
				 top10 option will use 10 most used provider 
				 The best option here is to add some domain yourself like this :
					 -gm @emailprovider1.com,@emailprovider2.ru
						 
				 Ex : -gm ._-,badidea00,leet,64,1984,666,all,top10,@emailprovider1.com,@emailprovider2.ru
						 
						
		           
		       -fa TRUE-FALSE, Check 946 city in France .Take more than 3 hours can get your ip banned
		
		       -LS, --lastsession  Load last aborded sessions
		
##Install

- pip3 install copernicus

Note that Darksearch, Skype, Facebook and some other modules are using Selenium
and needs geckodriver 0.16 wich is available only for 64 bits architecture.
geckodriver 0.16 for linux 64 bits is download automatically
at the first launch ( or if ./copernicus is not found) but Firefox 53 must be installed .

Copernicus.mtz can be used if you plan to import csv output to maltego .

##Usage

You can use it without argument :

	example@ofuse:~$ copernicus.py

Or with arguments:

	example@ofuse:~$ copernicus.py -e google,yahoo,pagesblanches,social,skype,facebook 
	-s "name+familyname" -f "Family name" 
	-c paris 
	-a lot,of,words,to,add,here,in,relation,with,the,people,"you are",searching 
	-i -m some@mail.something 
	-c2w
	-gm .-,top10,leet,666,@postmaster.co.uk,@openmailbox.org 
	-sk SkypeLogin,SkypePassword 
	-sf FacebookLogin,FacebookPassword
	-f2e 
	-n2w 
	 -o neo4j,csv
	 -tocsv Previous-results.csv
	   
###To do list:
- Learn python
- Rewrite all this shit
- Create Gui interface
- add other ppl search engine to social()
- add another method to find user if not found in social()
- Embed or use some part of https://github.com/joren485/Facebook-Location-OSINT
- Get metadata from pictures
- let users decide what picture are going to be use with sbi.
- Fix that fucking testmail validating username without @provider.com
- Let Selenium download avatars as it is searching facebook directory
- Find another way to get result from PagesBlanches if Error 403.
- ~~fix Facebook module (wtf Zack !? Look what uv done!)~~
- ~~Fix unicode problems.~~
- ~~Add Yandex Reverse Image to search engine.~~
- ~~Improve pictures comparison~~
- ~~Add Google image search and other search by image engine.~~
- ~~Embed or use some part of https://github.com/eth0izzle/the-endorser(Deleted by owner)~~
- ~~Check Fucking result from knowem.com (full of shit)~~
- ~~add www.yippy.com to deepdarkweb()~~
- ~~add http://www.emailbiz.info/ to guessmail()~~
- ~~replace Darksearch.com and add more onion search engine~~
- ~~Simplify cmd line interface/Create menu in cmd line~~
- ~~Let user choose their own resting time between each request .~~
- ~~Find a workaround if google return "Service Unvailable"~~
- ~~Fix Linkedin and Google+ in socialsearch lullar()~~
- ~~Rename lullar() to social()~~
- ~~Add github to social()~~
- ~~Add pastebin to social()~~
- ~~Add haveibeenpwned.com to social()~~
- ~~Add NameChk.com engine~~(merged in social())
-  ~~Add onion search engine~~
- ~~Add a lot of sites to improve social()~~
- ~~Append csv output to a previous csv file.~~
- ~~Allow searching for a real person and an alias at the same time.~~
- ~~Add Install setup~~
- ~~Add another way to check mails related to microsoft.~~
- ~~Add graphml , mtgx export format.~~ (replaced by csv export)
- ~~Add Irc Logs search.~~
- ~~Add TinEye search engine to compare with images results from Skype's avatar, Facebook ,and the first ten pictures from google bing  and yahoo.~~
-   ~~Add whitepage engine for fr.~~
-   ~~Add whitepage engine for uk.~~
-   ~~Add whitepage engine for es.~~
-   ~~Add whitepage engine for ru.~~
-   ~~Add whitepage engine for usa.~~
-   ~~Add whitepage engine for ger.~~=
-   ~~Add Captcha solver for yellowpages.com.~~
-   ~~Add ability to choose to use city for engine or whitePages.~~
-   ~~Add ability to save current session and continue where it stopped in  case of uncaught error.~~
-  ~~Add image search for yahoo and bing~~
- ~~Add Email search~~
- ~~Add Search results function for other file format.~~
- ~~Add nickname guessing function.~~(Canceled unreliable |Skype def or Facebook has better chances to find nickname or Alias)
- ~~Save final results session.~~
- ~~Add Skype search~~
- ~~Add Facebook search~~
- ~~Add webmii search~~ (Canceled results similar to Copernicus.py)
- ~~Add nickname searching function (instead of only using people's names.)~~
- ~~Check Lullar results for false positive.~~
- ~~Add email guessing function.~~
- ~~Add email checking function.~~
- ~~catch all mails found in results~~
- ~~Add FullAuto mode for PagesBlanches (testings all cities with more than 10 000 inhabitants )~~

*Wrote this cause of the maltego community limitation (12 results only)*